var hierarchy =
[
    [ "CasoDeTeste", "class_caso_de_teste.html", null ],
    [ "Desenvolvedor", "class_desenvolvedor.html", null ],
    [ "Dominio", "class_dominio.html", [
      [ "Classe", "class_classe.html", null ],
      [ "Codigo", "class_codigo.html", null ],
      [ "Data", "class_data.html", null ],
      [ "Matricula", "class_matricula.html", null ],
      [ "Resultado", "class_resultado.html", null ],
      [ "Senha", "class_senha.html", null ],
      [ "Telefone", "class_telefone.html", null ],
      [ "Texto", "class_texto.html", null ]
    ] ],
    [ "TestCasoDeTeste", "class_test_caso_de_teste.html", null ],
    [ "TestDesenvolvedor", "class_test_desenvolvedor.html", null ],
    [ "TestDominio", "class_test_dominio.html", [
      [ "TestClasse", "class_test_classe.html", null ],
      [ "TestCodigo", "class_test_codigo.html", null ],
      [ "TestData", "class_test_data.html", null ],
      [ "TestMatricula", "class_test_matricula.html", null ],
      [ "TestResultado", "class_test_resultado.html", null ],
      [ "TestSenha", "class_test_senha.html", null ],
      [ "TestTelefone", "class_test_telefone.html", null ],
      [ "TestTexto", "class_test_texto.html", null ]
    ] ],
    [ "Teste", "class_teste.html", null ],
    [ "TestTeste", "class_test_teste.html", null ]
];