var class_desenvolvedor =
[
    [ "getMatricula", "class_desenvolvedor.html#ae591c12a4bbd91d1c25f88cb06a147e8", null ],
    [ "getNome", "class_desenvolvedor.html#ae72a70ec08ae25864e4eda66ecceaa52", null ],
    [ "getSenha", "class_desenvolvedor.html#aa6841a9369baf7440ae621f88c1fa5ad", null ],
    [ "getTelefone", "class_desenvolvedor.html#a2c86429c9422fb1c281e4ff7ed3e4fe8", null ],
    [ "setMatricula", "class_desenvolvedor.html#a6a46e07a48c609df1b477d9b3789b15d", null ],
    [ "setNome", "class_desenvolvedor.html#a483e2c2decee72e467ebd6e9d22171fb", null ],
    [ "setSenha", "class_desenvolvedor.html#a92aec60284d9a133f9465f2d39dda42b", null ],
    [ "setTelefone", "class_desenvolvedor.html#a4700b541a9d616c53826c938b8fa0c89", null ]
];