var class_dominio =
[
    [ "getDado", "class_dominio.html#a781c7fa315fe32d37acd098300d50159", null ],
    [ "setDado", "class_dominio.html#a0092082135d66507cb9a904b2f68bf11", null ],
    [ "dado", "class_dominio.html#a4af16b4cdb4f80d5721c10c214f602d8", null ]
];