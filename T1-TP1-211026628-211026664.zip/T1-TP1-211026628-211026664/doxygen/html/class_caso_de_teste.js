var class_caso_de_teste =
[
    [ "getAcao", "class_caso_de_teste.html#a04eb097ddba174c9db57b236592f7fe6", null ],
    [ "getCodigo", "class_caso_de_teste.html#a68775e83df5383fbf47615a4f7f6728c", null ],
    [ "getData", "class_caso_de_teste.html#a8d0ee22f5ee7825a570f14ff5a079751", null ],
    [ "getNome", "class_caso_de_teste.html#a58a5358294156cfc90131b5b6da1f2c3", null ],
    [ "getResposta", "class_caso_de_teste.html#ac5d56ab43c281f8b335f1c3be49f32a8", null ],
    [ "getResultado", "class_caso_de_teste.html#a43a464ac3101441ad19de4c47a21c89d", null ],
    [ "setAcao", "class_caso_de_teste.html#ac570a465cf7ea94a9ed1cc0343e7e78d", null ],
    [ "setCodigo", "class_caso_de_teste.html#a7e3e3b369886dcac5d4c1101c53f5a61", null ],
    [ "setData", "class_caso_de_teste.html#af484337e787e79f353719da3e47b5a1e", null ],
    [ "setNome", "class_caso_de_teste.html#a33043eec76411f41f8c147326b6c3667", null ],
    [ "setResposta", "class_caso_de_teste.html#a3022335609d9d18a34c1ed1cf615cbca", null ],
    [ "setResultado", "class_caso_de_teste.html#acd51fad7439437c6642cdfa364cc1344", null ]
];