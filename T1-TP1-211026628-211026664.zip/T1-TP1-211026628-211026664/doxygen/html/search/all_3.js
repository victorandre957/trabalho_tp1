var searchData=
[
  ['matricula_0',['Matricula',['../class_matricula.html',1,'']]]
];
