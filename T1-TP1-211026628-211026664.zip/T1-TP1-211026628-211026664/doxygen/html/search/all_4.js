var searchData=
[
  ['resultado_0',['Resultado',['../class_resultado.html',1,'']]]
];
