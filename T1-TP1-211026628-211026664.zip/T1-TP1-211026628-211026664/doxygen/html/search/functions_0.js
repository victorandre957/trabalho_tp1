var searchData=
[
  ['getacao_0',['getAcao',['../class_caso_de_teste.html#a04eb097ddba174c9db57b236592f7fe6',1,'CasoDeTeste']]],
  ['getclasse_1',['getClasse',['../class_teste.html#ac1fe43548d940dfbfbc92eedf70e3f46',1,'Teste']]],
  ['getcodigo_2',['getCodigo',['../class_teste.html#a396e4d2d3624ab1af6a234d4f56b351f',1,'Teste::getCodigo()'],['../class_caso_de_teste.html#a68775e83df5383fbf47615a4f7f6728c',1,'CasoDeTeste::getCodigo()']]],
  ['getdado_3',['getDado',['../class_dominio.html#a781c7fa315fe32d37acd098300d50159',1,'Dominio']]],
  ['getdata_4',['getData',['../class_caso_de_teste.html#a8d0ee22f5ee7825a570f14ff5a079751',1,'CasoDeTeste']]],
  ['getmatricula_5',['getMatricula',['../class_desenvolvedor.html#ae591c12a4bbd91d1c25f88cb06a147e8',1,'Desenvolvedor']]],
  ['getnome_6',['getNome',['../class_desenvolvedor.html#ae72a70ec08ae25864e4eda66ecceaa52',1,'Desenvolvedor::getNome()'],['../class_teste.html#ae4d305019ccc4935005e07dfab239623',1,'Teste::getNome()'],['../class_caso_de_teste.html#a58a5358294156cfc90131b5b6da1f2c3',1,'CasoDeTeste::getNome() const']]],
  ['getresposta_7',['getResposta',['../class_caso_de_teste.html#ac5d56ab43c281f8b335f1c3be49f32a8',1,'CasoDeTeste']]],
  ['getresultado_8',['getResultado',['../class_caso_de_teste.html#a43a464ac3101441ad19de4c47a21c89d',1,'CasoDeTeste']]],
  ['getsenha_9',['getSenha',['../class_desenvolvedor.html#aa6841a9369baf7440ae621f88c1fa5ad',1,'Desenvolvedor']]],
  ['gettelefone_10',['getTelefone',['../class_desenvolvedor.html#a2c86429c9422fb1c281e4ff7ed3e4fe8',1,'Desenvolvedor']]]
];
