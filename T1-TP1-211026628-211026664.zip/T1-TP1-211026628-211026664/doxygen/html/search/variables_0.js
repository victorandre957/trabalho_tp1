var searchData=
[
  ['dado_0',['dado',['../class_dominio.html#a4af16b4cdb4f80d5721c10c214f602d8',1,'Dominio']]]
];
